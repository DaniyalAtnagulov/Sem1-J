public class task1 {
    public String reverseWords(String s) {
        if (s == null) return s;

        String[] strs = s.split(" ");
        StringBuffer sb = new StringBuffer();
        for (String str : strs) {
            if (str.length() != 0) sb.insert(0, str + " ");
        }
        return sb.toString().trim();
    }
}